###### If you are getting
###### Exception in ContentProvider: Unknown kind ''
###### Quota Exceeded
###### anything to do with content not working, more than likely 
###### you've hit the famous Youtube Quote usage problem.

![](https://raw.githubusercontent.com/Kolifanes/plugin.video.youtube/master/icon.png)
# **Links:**

* [YouTube](http://www.youtube.com)
* [Support thread](http://forum.kodi.tv/showthread.php?tid=267160)

# **Images:**
![](http://i.imgur.com/W5UEby8.png)
![](http://i.imgur.com/rfqpIYC.png)
![](http://i.imgur.com/hoIuZ1K.png)
